# Inventory App – Project Three (Functional Build)

A warehouse stock-tracking Android app. This build adds the working code on top
of the Project Two UI: real login, a persistent SQLite database with full CRUD,
and functional low-stock SMS alerts gated behind a runtime permission request.

## How to open

Open this folder in Android Studio (the one containing `settings.gradle`), let
Gradle sync, then run on an emulator or device. `LoginActivity` is the launcher.

## Login (`LoginActivity` + `DatabaseHelper`)
- **Log In** checks the username/password against the `users` table.
- **Create Account** adds a new login to the `users` table (usernames are
  unique). First-time users go this route.
- Passwords are stored as SHA-256 hashes, never in plain text.

## Database + grid (`DatabaseHelper`, `InventoryActivity`, `InventoryAdapter`)
A persistent SQLite database (`inventory.db`) with two tables: `users` and
`inventory`. The inventory grid supports all four operations:
- **Create** – the Add Item screen inserts a new record.
- **Read** – the grid lists every record (two-column `GridLayoutManager`).
- **Update** – the + / − buttons on each cell change the stored quantity.
- **Delete** – the Remove button deletes the record.
The database is only a shell: the user populates it at runtime.

## SMS alerts (`InventoryActivity`)
When an item's quantity drops to or below its low-stock threshold, the app tries
to send an SMS alert:
- It checks the `SEND_SMS` permission first and requests it at runtime if needed.
- **Granted** → the alert is sent via `SmsManager`.
- **Denied** → the app keeps working normally; only the alert is skipped.
Set the alert destination in `InventoryActivity.ALERT_PHONE_NUMBER`.

## Testing in the emulator
1. Create an account, then log in with it.
2. Add a few items, including one with quantity at/below its threshold to trigger
   an alert. Accept the permission once, then deny on a later run to confirm the
   app still works without alerts.
3. Use + / − to update quantities and Remove to delete; close and reopen the app
   to confirm the data persists.

Package: `com.mobile2app.inventory` · compileSdk 34 · minSdk 24 · Java 17
