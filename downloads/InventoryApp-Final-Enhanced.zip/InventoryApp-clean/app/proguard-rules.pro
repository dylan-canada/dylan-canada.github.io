# Default ProGuard rules. No custom rules are needed for this project.
