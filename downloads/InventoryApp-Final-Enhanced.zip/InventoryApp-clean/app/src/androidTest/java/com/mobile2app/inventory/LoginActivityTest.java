package com.mobile2app.inventory;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * Instrumented UI tests for {@link LoginActivity}, run on a device or
 * emulator. Covers the two behaviors called out in the rubric: the screen
 * renders its core controls, and submitting with empty fields is rejected
 * without navigating away.
 */
@RunWith(AndroidJUnit4.class)
public class LoginActivityTest {

    @Rule
    public ActivityScenarioRule<LoginActivity> activityRule =
            new ActivityScenarioRule<>(LoginActivity.class);

    @Test
    public void loginScreen_displaysUsernamePasswordAndButtons() {
        onView(withId(R.id.editUsername)).check(matches(isDisplayed()));
        onView(withId(R.id.editPassword)).check(matches(isDisplayed()));
        onView(withId(R.id.buttonLogin)).check(matches(isDisplayed()));
        onView(withId(R.id.buttonCreateAccount)).check(matches(isDisplayed()));
    }

    @Test
    public void attemptLogin_withEmptyFields_staysOnLoginScreen() {
        onView(withId(R.id.buttonLogin)).perform(click());

        // Empty-field validation should block the login attempt entirely,
        // so the login form is still on screen afterward.
        onView(withId(R.id.editUsername)).check(matches(isDisplayed()));
        onView(withId(R.id.editPassword)).check(matches(isDisplayed()));
    }
}
