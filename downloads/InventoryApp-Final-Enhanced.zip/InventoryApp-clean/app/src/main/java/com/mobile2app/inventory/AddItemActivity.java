package com.mobile2app.inventory;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

/**
 * Form for adding a new inventory record.
 *
 * <p>Users can now assign each inventory item to a category. Category data is
 * loaded through {@link InventoryRepository}, while all database operations
 * continue to run off the main thread.</p>
 */
public class AddItemActivity extends AppCompatActivity {

    private InventoryRepository inventoryRepository;

    private TextInputEditText editName;
    private TextInputEditText editSku;
    private TextInputEditText editQuantity;
    private TextInputEditText editThreshold;

    private Spinner spinnerCategory;
    private MaterialButton buttonSave;

    private final List<Category> categories = new ArrayList<>();

    private ArrayAdapter<Category> categoryAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        inventoryRepository = new InventoryRepository(this);

        initializeViews();
        initializeCategorySpinner();
        loadCategories();
        initializeButtons();
    }

    /**
     * Finds and stores references to the form controls.
     */
    private void initializeViews() {
        editName = findViewById(R.id.editItemName);
        editSku = findViewById(R.id.editItemSku);
        editQuantity = findViewById(R.id.editItemQuantity);
        editThreshold = findViewById(R.id.editItemThreshold);
        spinnerCategory = findViewById(R.id.spinnerCategory);
        buttonSave = findViewById(R.id.buttonSaveItem);
    }

    /**
     * Configures the adapter used to display category names.
     */
    private void initializeCategorySpinner() {
        categoryAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                categories
        );

        categoryAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerCategory.setAdapter(categoryAdapter);
    }

    /**
     * Loads all categories from the normalized categories table.
     */
    private void loadCategories() {
        buttonSave.setEnabled(false);

        inventoryRepository.getAllCategories(result -> {
            categories.clear();
            categories.addAll(result);
            categoryAdapter.notifyDataSetChanged();

            boolean categoriesAvailable = !categories.isEmpty();

            buttonSave.setEnabled(categoriesAvailable);

            if (!categoriesAvailable) {
                Toast.makeText(
                        this,
                        R.string.error_categories_unavailable,
                        Toast.LENGTH_LONG
                ).show();
            }
        });
    }

    /**
     * Configures Save and Cancel actions.
     */
    private void initializeButtons() {
        MaterialButton buttonCancel =
                findViewById(R.id.buttonCancel);

        buttonSave.setOnClickListener(
                view -> saveItem()
        );

        buttonCancel.setOnClickListener(
                view -> finish()
        );
    }

    /**
     * Validates the form and saves a categorized inventory record.
     */
    private void saveItem() {
        String name = readField(editName);
        String sku = readField(editSku);

        if (ValidationUtils.isBlank(name)) {
            Toast.makeText(
                    this,
                    R.string.error_name_required,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        Integer quantity =
                ValidationUtils.parseNonNegativeInt(
                        readField(editQuantity)
                );

        if (quantity == null) {
            Toast.makeText(
                    this,
                    R.string.error_quantity_invalid,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        Integer threshold =
                ValidationUtils.parseNonNegativeInt(
                        readField(editThreshold)
                );

        if (threshold == null) {
            Toast.makeText(
                    this,
                    R.string.error_threshold_invalid,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        Category selectedCategory =
                (Category) spinnerCategory.getSelectedItem();

        if (selectedCategory == null) {
            Toast.makeText(
                    this,
                    R.string.error_categories_unavailable,
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        buttonSave.setEnabled(false);

        inventoryRepository.addItem(
                name,
                sku,
                quantity,
                threshold,
                selectedCategory.getId(),
                success -> {
                    buttonSave.setEnabled(true);

                    if (success) {
                        Toast.makeText(
                                this,
                                R.string.item_added,
                                Toast.LENGTH_SHORT
                        ).show();

                        finish();
                    } else {
                        Toast.makeText(
                                this,
                                R.string.error_save_failed,
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                }
        );
    }

    /**
     * Safely reads and trims a text field.
     */
    private String readField(TextInputEditText field) {
        return field.getText() == null
                ? ""
                : field.getText().toString().trim();
    }
}