package com.mobile2app.inventory;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Persists the SMS low-stock alert destination number.
 *
 * <p>This replaces the previous {@code ALERT_PHONE_NUMBER} constant that was
 * hardcoded in {@code InventoryActivity}. The number is now stored in
 * SharedPreferences and editable from the Inventory screen's overflow menu,
 * with the old hardcoded value kept only as the first-run default.</p>
 */
public final class AlertSettings {

    private static final String PREFS_NAME = "alert_settings";
    private static final String KEY_PHONE_NUMBER = "alert_phone_number";

    // Same value as the previous hardcoded constant, now just the default
    // shown before a user configures their own number.
    private static final String DEFAULT_PHONE_NUMBER = "5551234567";

    private final SharedPreferences prefs;

    public AlertSettings(Context context) {
        prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public String getPhoneNumber() {
        return prefs.getString(KEY_PHONE_NUMBER, DEFAULT_PHONE_NUMBER);
    }

    public void setPhoneNumber(String phoneNumber) {
        prefs.edit().putString(KEY_PHONE_NUMBER, phoneNumber).apply();
    }
}
