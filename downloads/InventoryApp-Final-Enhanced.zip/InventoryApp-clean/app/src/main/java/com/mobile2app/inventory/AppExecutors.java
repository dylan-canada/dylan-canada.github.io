package com.mobile2app.inventory;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Shared background/main-thread dispatcher used by the repository classes.
 *
 * <p>Before this enhancement, {@link DatabaseHelper} was called directly from
 * Activities on the main thread, which risks janky UI or ANRs as the
 * inventory table grows. Repositories now route every database call through
 * {@link #diskIO(Runnable)} and hop back to {@link #mainThread(Runnable)}
 * only to deliver the result, keeping SQLite work off the UI thread.</p>
 *
 * <p>A single-thread executor is enough here: this is a small, single-user
 * local database, so there's no benefit to parallel reads/writes, and a
 * single thread keeps operations naturally ordered.</p>
 */
public final class AppExecutors {

    private static volatile AppExecutors instance;

    private final ExecutorService diskIO = Executors.newSingleThreadExecutor();
    private final Handler mainThreadHandler = new Handler(Looper.getMainLooper());

    private AppExecutors() {
    }

    public static AppExecutors getInstance() {
        if (instance == null) {
            synchronized (AppExecutors.class) {
                if (instance == null) {
                    instance = new AppExecutors();
                }
            }
        }
        return instance;
    }

    /** Runs {@code task} on the background database thread. */
    public void diskIO(Runnable task) {
        diskIO.execute(task);
    }

    /** Runs {@code task} on the main/UI thread. */
    public void mainThread(Runnable task) {
        mainThreadHandler.post(task);
    }
}
