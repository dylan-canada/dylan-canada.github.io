package com.mobile2app.inventory;

import android.content.Context;

/**
 * Mediates authentication data access between {@link LoginActivity} and
 * {@link DatabaseHelper}, mirroring {@link InventoryRepository}. Login and
 * account-creation checks now run off the main thread, and LoginActivity no
 * longer touches SQLite directly.
 */
public class AuthRepository {

    /** Callback for login/account-creation results. */
    public interface AuthCallback {
        void onResult(boolean success);
    }

    private final DatabaseHelper databaseHelper;
    private final AppExecutors executors;

    public AuthRepository(Context context) {
        this.databaseHelper = new DatabaseHelper(context.getApplicationContext());
        this.executors = AppExecutors.getInstance();
    }

    /** Checks a username/password pair in the background. */
    public void login(String username, String password, AuthCallback callback) {
        executors.diskIO(() -> {
            boolean valid = databaseHelper.checkCredentials(username, password);
            executors.mainThread(() -> callback.onResult(valid));
        });
    }

    /** Creates a new account in the background. */
    public void createAccount(String username, String password, AuthCallback callback) {
        executors.diskIO(() -> {
            boolean created = databaseHelper.createUser(username, password);
            executors.mainThread(() -> callback.onResult(created));
        });
    }
}
