package com.mobile2app.inventory;

/**
 * Represents one inventory category stored in the categories table.
 */
public class Category {

    private final long id;
    private final String name;

    public Category(long id, String name) {
        this.id = id;
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }
}