package com.mobile2app.inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

/**
 * Central access point for the app's SQLite database.
 *
 * <p>The database is persistent: it lives on the device's internal storage and
 * keeps its contents between launches. It holds two tables:</p>
 * <ul>
 *     <li>{@code users}     – login credentials (username + hashed password)</li>
 *     <li>{@code inventory} – the stock records shown in the grid</li>
 * </ul>
 *
 * <p>This class only builds the database "shell" (the tables and the operations
 * that act on them). The user populates the inventory table at runtime through
 * the app.</p>
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database file name and schema version. Bump the version to trigger onUpgrade.
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 3;

    // ---- users table ----
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD_HASH = "password_hash";
    private static final String COL_PASSWORD_SALT = "password_salt";

    // ---- inventory table ----
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COL_ITEM_ID = "_id";
    private static final String COL_ITEM_NAME = "name";
    private static final String COL_ITEM_SKU = "sku";
    private static final String COL_ITEM_QUANTITY = "quantity";
    private static final String COL_ITEM_THRESHOLD = "low_stock_threshold";

    // ---- categories table ----
    private static final String TABLE_CATEGORIES = "categories";
    private static final String COL_CATEGORY_ID = "_id";
    private static final String COL_CATEGORY_NAME = "name";

    // Foreign-key column stored in the inventory table.
    private static final String COL_ITEM_CATEGORY_ID = "category_id";

    // Default category used when migrating existing inventory records.
    private static final long DEFAULT_CATEGORY_ID = 1L;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Enables SQLITE foreign-key enforcement every time the database is opened.
     */
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    /**
     * Called the first time the database is created. Builds both tables.
     *
     * The schema now contains three related tables: users, categories, and
     * inventory. Inventory records reference categories through a foreign key.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        createUsersTable(db);
        createCategoriesTable(db);
        seedDefaultCategories(db);
        createInventoryTable(db);
        createInventoryIndexes(db);
    }

    /**
     * Called when DATABASE_VERSION increases. For this project we simply drop
     * and recreate; a production app would migrate existing data instead.
     *
     * <p>This is a known limitation, tracked for the database-focused
     * enhancement milestone: a real migration path (e.g. {@code ALTER TABLE})
     * is needed so schema changes stop destroying existing data. It is left
     * as-is here because this milestone's scope is software design and
     * engineering, not the database schema itself.</p>
     *
     * ---- New Changes ----
     * Migrates older database versions without deleting existing users or
     * inventory records.
     * No longer deletes entirety of old tables.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 3) {
            migrateToVersion3(db);
        }
    }

    /**
     * Creates the users table.
     */
    private void createUsersTable(SQLiteDatabase db) {
        String createUsers =
                "CREATE TABLE IF NOT EXISTS " + TABLE_USERS + " (" +
                        COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                        COL_PASSWORD_HASH + " TEXT NOT NULL, " +
                        COL_PASSWORD_SALT + " TEXT NOT NULL)";

        db.execSQL(createUsers);
    }

    /**
     * Creates the normalized categories table.
     *
     * The UNIQUE constraint prevents duplicate category names.
     */
    private void createCategoriesTable(SQLiteDatabase db) {
        String createCategories =
                "CREATE TABLE IF NOT EXISTS " + TABLE_CATEGORIES + " (" +
                        COL_CATEGORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_CATEGORY_NAME + " TEXT UNIQUE NOT NULL)";

        db.execSQL(createCategories);
    }

    /**
     * Creates the inventory table with a foreign-key relationship to categories.
     */
    private void createInventoryTable(SQLiteDatabase db) {
        String createInventory =
                "CREATE TABLE IF NOT EXISTS " + TABLE_INVENTORY + " (" +
                        COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_ITEM_NAME + " TEXT NOT NULL, " +
                        COL_ITEM_SKU + " TEST, " +
                        COL_ITEM_QUANTITY + " INTEGER NOT NULL DEFAULT 0 " +
                        "CHECK (" + COL_ITEM_QUANTITY + " >= 0), " +
                        COL_ITEM_THRESHOLD + " INTEGER NOT NULL DEFAULT 0 " +
                        "CHECK (" + COL_ITEM_THRESHOLD + " >= 0), " +
                        COL_ITEM_CATEGORY_ID + " INTEGER NOT NULL DEFAULT " +
                        DEFAULT_CATEGORY_ID + ", " +
                        "FOREIGN KEY (" + COL_ITEM_CATEGORY_ID + ") REFERENCES " +
                        TABLE_CATEGORIES + "(" + COL_CATEGORY_ID + ") " +
                        "ON UPDATE CASCADE ON DELETE RESTRICT)";

        db.execSQL(createInventory);
    }

    /**
     * Creates indexes for columns used frequently by searches and category filters.
     */
    private void createInventoryIndexes(SQLiteDatabase db) {
        db.execSQL(
                "CREATE INDEX IF NOT EXISTS index_inventory_sku ON " +
                        TABLE_INVENTORY + "(" + COL_ITEM_SKU + ")"
        );

        db.execSQL(
                "CREATE INDEX IF NOT EXISTS index_inventory_category ON " +
                        TABLE_INVENTORY + "(" + COL_ITEM_CATEGORY_ID + ")"
        );
    }

    /**
     * Adds the default categories used by new installations and migrations.
     *
     * <p>Explicit IDs guarantee that category 1 is always Uncategorized, which
     * allows old inventory records to migrate safely.</p>
     */
    private void seedDefaultCategories(SQLiteDatabase db) {
        insertCategoryIfMissing(db, 1L, "Uncategorized");
        insertCategoryIfMissing(db, 2L, "Electronics");
        insertCategoryIfMissing(db, 3L, "Office Supplies");
        insertCategoryIfMissing(db, 4L, "Furniture");
        insertCategoryIfMissing(db, 5L, "Other");
    }

    /**
     * Inserts one seeded category without creating duplicates.
     */
    private void insertCategoryIfMissing(
            SQLiteDatabase db,
            long categoryId,
            String categoryName) {

        ContentValues values = new ContentValues();
        values.put(COL_CATEGORY_ID, categoryId);
        values.put(COL_CATEGORY_NAME, categoryName);

        db.insertWithOnConflict(
                TABLE_CATEGORIES,
                null,
                values,
                SQLiteDatabase.CONFLICT_IGNORE
        );
    }

    /**
     * Migrates the version-2 inventory schema to version 3.
     *
     * <p>SQLite cannot add a complete foreign-key constraint to an existing table
     * with a simple ALTER TABLE statement, so the migration creates a replacement
     * table, copies all records, and then renames it. Existing users and inventory
     * data are preserved.</p>
     */
    private void migrateToVersion3(SQLiteDatabase db) {
        db.beginTransaction();

        try {
            createCategoriesTable(db);
            seedDefaultCategories(db);

            String temporaryTable = TABLE_INVENTORY + "_new";

            db.execSQL(
                    "CREATE TABLE " + temporaryTable + " (" +
                            COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                            COL_ITEM_NAME + " TEXT NOT NULL, " +
                            COL_ITEM_SKU + " TEXT, " +
                            COL_ITEM_QUANTITY + " INTEGER NOT NULL DEFAULT 0 " +
                            "CHECK (" + COL_ITEM_QUANTITY + " >= 0), " +
                            COL_ITEM_THRESHOLD + " INTEGER NOT NULL DEFAULT 0 " +
                            "CHECK (" + COL_ITEM_THRESHOLD + " >= 0), " +
                            COL_ITEM_CATEGORY_ID + " INTEGER NOT NULL DEFAULT " +
                            DEFAULT_CATEGORY_ID + ", " +
                            "FOREIGN KEY (" + COL_ITEM_CATEGORY_ID + ") REFERENCES " +
                            TABLE_CATEGORIES + "(" + COL_CATEGORY_ID + ") " +
                            "ON UPDATE CASCADE ON DELETE RESTRICT)"
            );

            /*
             * Copy every existing inventory record into the normalized schema.
             * Existing records are assigned to the Uncategorized category.
             */
            db.execSQL(
                    "INSERT INTO " + temporaryTable + " (" +
                            COL_ITEM_ID + ", " +
                            COL_ITEM_NAME + ", " +
                            COL_ITEM_SKU + ", " +
                            COL_ITEM_QUANTITY + ", " +
                            COL_ITEM_THRESHOLD + ", " +
                            COL_ITEM_CATEGORY_ID + ") " +
                            "SELECT " +
                            COL_ITEM_ID + ", " +
                            COL_ITEM_NAME + ", " +
                            COL_ITEM_SKU + ", " +
                            COL_ITEM_QUANTITY + ", " +
                            COL_ITEM_THRESHOLD + ", " +
                            DEFAULT_CATEGORY_ID +
                            " FROM " + TABLE_INVENTORY
            );

            db.execSQL("DROP TABLE " + TABLE_INVENTORY);

            db.execSQL(
                    "ALTER TABLE " + temporaryTable +
                            " RENAME TO " + TABLE_INVENTORY
            );

            createInventoryIndexes(db);

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    // ====================================================================
    //  User / authentication operations
    // ====================================================================

    /**
     * Returns true if the username already exists in the users table.
     */
    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + " = ?",
                new String[]{username},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    /**
     * Creates a new account. Returns true on success, or false if the username
     * is already taken (usernames must be unique).
     *
     * <p>Each account gets its own randomly generated salt, so two users with
     * the same password never produce the same stored hash, and precomputed
     * (rainbow-table) attacks against the hash column don't work.</p>
     */
    public boolean createUser(String username, String password) {
        if (userExists(username)) {
            return false;
        }
        String salt = generateSalt();
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD_SALT, salt);
        values.put(COL_PASSWORD_HASH, hash(password, salt));
        long newRowId = db.insert(TABLE_USERS, null, values);
        return newRowId != -1;
    }

    /**
     * Checks a username/password pair against the stored credentials, using
     * that user's stored salt to recompute the hash for comparison.
     *
     * @return true when the username exists and the password matches.
     */
    public boolean checkCredentials(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_PASSWORD_HASH, COL_PASSWORD_SALT},
                COL_USERNAME + " = ?",
                new String[]{username},
                null, null, null);

        boolean valid = false;
        if (cursor.moveToFirst()) {
            String storedHash = cursor.getString(0);
            String storedSalt = cursor.getString(1);
            valid = storedHash.equals(hash(password, storedSalt));
        }
        cursor.close();
        return valid;
    }

    /**
     * Generates a random, per-user salt as a hex string. Called once per
     * account, at creation time, and stored alongside the resulting hash.
     */
    private String generateSalt() {
        byte[] saltBytes = new byte[16];
        new SecureRandom().nextBytes(saltBytes);
        return toHex(saltBytes);
    }

    /**
     * Hashes a plain-text password together with a salt using SHA-256, so the
     * raw password is never written to the database and identical passwords
     * across accounts don't produce identical stored hashes.
     */
    private String hash(String input, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(salt.getBytes());
            byte[] bytes = digest.digest(input.getBytes());
            return toHex(bytes);
        } catch (NoSuchAlgorithmException e) {
            // SHA-256 is guaranteed to be available on Android, so this never fires.
            throw new RuntimeException("SHA-256 not available", e);
        }
    }

    private String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    // ====================================================================
    //  Category CRUD operations
    // ====================================================================

    /**
     * Returns all categories ordered alphabetically.
     */
    public List<Category> getAllCategories() {
        List<Category> categories = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_CATEGORIES,
                new String[]{
                        COL_CATEGORY_ID,
                        COL_CATEGORY_NAME
                },
                null,
                null,
                null,
                null,
                COL_CATEGORY_NAME + " ASC"
        );

        while (cursor.moveToNext()) {
            categories.add(
                    new Category(
                            cursor.getLong(
                                    cursor.getColumnIndexOrThrow(
                                            COL_CATEGORY_ID
                                    )
                            ),
                            cursor.getString(
                                    cursor.getColumnIndexOrThrow(
                                            COL_CATEGORY_NAME
                                    )
                            )
                    )
            );
        }

        cursor.close();
        return categories;
    }

    /**
     * Creates a category.
     *
     * @return the generated row ID, or -1 if the category already exists.
     */
    public long addCategory(String categoryName) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_CATEGORY_NAME, categoryName.trim());

        return db.insert(
                TABLE_CATEGORIES,
                null,
                values
        );
    }

    /**
     * Renames an existing category.
     */
    public int updateCategory(long categoryId, String categoryName) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_CATEGORY_NAME, categoryName.trim());

        return db.update(
                TABLE_CATEGORIES,
                values,
                COL_CATEGORY_ID + " = ?",
                new String[]{String.valueOf(categoryId)}
        );
    }

    /**
     * Deletes a category.
     *
     * <p>The database prevents deletion when inventory records still reference
     * the category because the foreign key uses ON DELETE RESTRICT.</p>
     */
    public int deleteCategory(long categoryId) {
        SQLiteDatabase db = getWritableDatabase();

        return db.delete(
                TABLE_CATEGORIES,
                COL_CATEGORY_ID + " = ?",
                new String[]{String.valueOf(categoryId)}
        );
    }

    // ====================================================================
    //  Inventory CRUD operations
    // ====================================================================

    /**
     * Creates an item in the Uncategorized category.
     */
    public long addItem(
            String name,
            String sku,
            int quantity,
            int threshold) {

        return addItem(
                name,
                sku,
                quantity,
                threshold,
                DEFAULT_CATEGORY_ID
        );
    }

    /**
     * Creates an item assigned to a selected category.
     */
    public long addItem(
            String name,
            String sku,
            int quantity,
            int threshold,
            long categoryId) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_SKU, sku);
        values.put(COL_ITEM_QUANTITY, quantity);
        values.put(COL_ITEM_THRESHOLD, threshold);
        values.put(COL_ITEM_CATEGORY_ID, categoryId);

        return db.insert(
                TABLE_INVENTORY,
                null,
                values
        );
    }

    /**
     * Returns all inventory records with their related category names.
     *
     * <p>This query demonstrates a relational JOIN between the inventory and
     * categories tables.</p>
     */
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        String query =
                "SELECT " +
                        "i." + COL_ITEM_ID + ", " +
                        "i." + COL_ITEM_NAME + ", " +
                        "i." + COL_ITEM_SKU + ", " +
                        "i." + COL_ITEM_QUANTITY + ", " +
                        "i." + COL_ITEM_THRESHOLD + ", " +
                        "i." + COL_ITEM_CATEGORY_ID + ", " +
                        "c." + COL_CATEGORY_NAME + " AS category_name " +
                        "FROM " + TABLE_INVENTORY + " i " +
                        "INNER JOIN " + TABLE_CATEGORIES + " c " +
                        "ON i." + COL_ITEM_CATEGORY_ID +
                        " = c." + COL_CATEGORY_ID + " " +
                        "ORDER BY i." + COL_ITEM_NAME + " ASC";

        Cursor cursor = db.rawQuery(query, null);

        while (cursor.moveToNext()) {
            InventoryItem item = new InventoryItem(
                    cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                    COL_ITEM_ID
                            )
                    ),
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    COL_ITEM_NAME
                            )
                    ),
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    COL_ITEM_SKU
                            )
                    ),
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    COL_ITEM_QUANTITY
                            )
                    ),
                    cursor.getInt(
                            cursor.getColumnIndexOrThrow(
                                    COL_ITEM_THRESHOLD
                            )
                    ),
                    cursor.getLong(
                            cursor.getColumnIndexOrThrow(
                                    COL_ITEM_CATEGORY_ID
                            )
                    ),
                    cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                    "category_name"
                            )
                    )
            );

            items.add(item);
        }

        cursor.close();
        return items;
    }

    /**
     * UPDATE: changes the quantity of one record. Used by the +/- controls on
     * each grid row. Returns the number of rows affected (1 on success).
     */
    public int updateQuantity(long id, int newQuantity) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_QUANTITY, newQuantity);
        return db.update(
                TABLE_INVENTORY,
                values,
                COL_ITEM_ID + " = ?",
                new String[]{String.valueOf(id)});
    }

    /**
     * Updates all editable fields for an inventory record.
     */
    public int updateItem(
            long itemId,
            String name,
            String sku,
            int quantity,
            int threshold,
            long categoryId) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_SKU, sku);
        values.put(COL_ITEM_QUANTITY, quantity);
        values.put(COL_ITEM_THRESHOLD, threshold);
        values.put(COL_ITEM_CATEGORY_ID, categoryId);

        return db.update(
                TABLE_INVENTORY,
                values,
                COL_ITEM_ID + " = ?",
                new String[]{String.valueOf(itemId)}
        );
    }

    /**
     * DELETE: removes one record by id. Returns the number of rows deleted.
     */
    public int deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(
                TABLE_INVENTORY,
                COL_ITEM_ID + " = ?",
                new String[]{String.valueOf(id)});
    }
}
