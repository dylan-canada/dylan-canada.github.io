package com.mobile2app.inventory;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Main inventory screen.
 *
 * <p>This activity displays inventory records and now supports searching,
 * filtering, sorting, exact SKU indexing, and inventory analytics. The
 * algorithm logic is contained in {@link InventoryAlgorithms} so the activity
 * remains focused on user-interface behavior.</p>
 */
public class InventoryActivity extends AppCompatActivity
        implements InventoryAdapter.OnItemActionListener {

    private InventoryRepository inventoryRepository;
    private AlertSettings alertSettings;
    private InventoryAdapter adapter;

    private TextView textEmpty;
    private TextView textResultCount;
    private TextView textStatistics;
    private TextInputEditText editSearchInventory;
    private MaterialCheckBox checkLowStockOnly;
    private Spinner spinnerSort;

    private Spinner spinnerCategoryFilter;

    private final List<Category> categories =
            new ArrayList<>();

    private long selectedCategoryId = -1;

    /*
     * allItems contains the complete inventory loaded from the database.
     * displayedItems contains only the filtered and sorted records shown in
     * the RecyclerView.
     */
    private final List<InventoryItem> allItems = new ArrayList<>();
    private final List<InventoryItem> displayedItems = new ArrayList<>();

    /*
     * The SKU index provides average O(1) exact lookup after it is built.
     */
    private Map<String, InventoryItem> skuIndex;

    private InventoryAlgorithms.SortMode currentSortMode =
            InventoryAlgorithms.SortMode.NAME_ASCENDING;

    private String pendingAlertMessage;

    /**
     * Runtime permission launcher for SEND_SMS.
     */
    private final ActivityResultLauncher<String> requestSmsPermission =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        if (isGranted) {
                            if (pendingAlertMessage != null) {
                                sendSms(pendingAlertMessage);
                            }
                        } else {
                            Toast.makeText(
                                    this,
                                    R.string.sms_denied_keep_working,
                                    Toast.LENGTH_LONG
                            ).show();
                        }

                        pendingAlertMessage = null;
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        inventoryRepository = new InventoryRepository(this);
        alertSettings = new AlertSettings(this);

        initializeViews();
        initializeToolbar();
        initializeRecyclerView();
        initializeSearch();
        initializeSortSpinner();
        initializeCategorySpinner();
        initializeLowStockFilter();
        initializeAddButton();
    }

    /**
     * Finds and stores references to the screen controls.
     */
    private void initializeViews() {
        textEmpty = findViewById(R.id.textEmpty);
        textResultCount = findViewById(R.id.textResultCount);
        textStatistics = findViewById(R.id.textStatistics);
        editSearchInventory = findViewById(R.id.editSearchInventory);
        checkLowStockOnly = findViewById(R.id.checkLowStockOnly);
        spinnerSort = findViewById(R.id.spinnerSort);
        spinnerCategoryFilter =
                findViewById(R.id.spinnerCategoryFilter);
    }

    /**
     * Configures the Material toolbar.
     */
    private void initializeToolbar() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    /**
     * Configures the two-column inventory grid.
     */
    private void initializeRecyclerView() {
        RecyclerView recyclerView = findViewById(R.id.recyclerInventory);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        adapter = new InventoryAdapter(displayedItems, this);
        recyclerView.setAdapter(adapter);
    }

    /**
     * Reapplies the filtering and sorting algorithms whenever the search text
     * changes.
     */
    private void initializeSearch() {
        editSearchInventory.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(
                    CharSequence text,
                    int start,
                    int count,
                    int after) {
                // No action required.
            }

            @Override
            public void onTextChanged(
                    CharSequence text,
                    int start,
                    int before,
                    int count) {
                applyInventoryAlgorithms();
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // No action required.
            }
        });
    }

    /**
     * Configures the sorting choices and maps each spinner position to a
     * sorting strategy.
     */
    private void initializeSortSpinner() {
        ArrayAdapter<CharSequence> sortAdapter =
                ArrayAdapter.createFromResource(
                        this,
                        R.array.inventory_sort_options,
                        android.R.layout.simple_spinner_item
                );

        sortAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        spinnerSort.setAdapter(sortAdapter);

        spinnerSort.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(
                            AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {

                        switch (position) {
                            case 1:
                                currentSortMode =
                                        InventoryAlgorithms.SortMode
                                                .QUANTITY_ASCENDING;
                                break;

                            case 2:
                                currentSortMode =
                                        InventoryAlgorithms.SortMode
                                                .QUANTITY_DESCENDING;
                                break;

                            case 3:
                                currentSortMode =
                                        InventoryAlgorithms.SortMode
                                                .LOW_STOCK_FIRST;
                                break;

                            case 0:
                            default:
                                currentSortMode =
                                        InventoryAlgorithms.SortMode
                                                .NAME_ASCENDING;
                                break;
                        }

                        applyInventoryAlgorithms();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                        // Keep the existing sort mode.
                    }
                }
        );
    }

    private void initializeCategorySpinner() {

        inventoryRepository.getAllCategories(result -> {

            categories.clear();

            categories.add(new Category(-1, "All Categories"));

            categories.addAll(result);

            ArrayAdapter<Category> categoryAdapter =
                    new ArrayAdapter<>(
                            this,
                            android.R.layout.simple_spinner_item,
                            categories
                    );

            categoryAdapter.setDropDownViewResource(
                    android.R.layout.simple_spinner_dropdown_item
            );

            spinnerCategoryFilter.setAdapter(categoryAdapter);

            spinnerCategoryFilter.setOnItemSelectedListener(
                    new AdapterView.OnItemSelectedListener() {

                        @Override
                        public void onItemSelected(
                                AdapterView<?> parent,
                                View view,
                                int position,
                                long id) {

                            selectedCategoryId =
                                    categories.get(position).getId();

                            applyInventoryAlgorithms();
                        }

                        @Override
                        public void onNothingSelected(
                                AdapterView<?> parent) {
                        }
                    });
        });
    }

    /**
     * Limits displayed records to low-stock items when checked.
     */
    private void initializeLowStockFilter() {
        checkLowStockOnly.setOnCheckedChangeListener(
                (buttonView, isChecked) -> applyInventoryAlgorithms()
        );
    }

    /**
     * Opens the add-item screen.
     */
    private void initializeAddButton() {
        ExtendedFloatingActionButton fabAdd =
                findViewById(R.id.fabAddItem);

        fabAdd.setOnClickListener(
                view -> startActivity(
                        new Intent(this, AddItemActivity.class)
                )
        );
    }

    /**
     * Reloads inventory each time this activity returns to the foreground.
     */
    @Override
    protected void onResume() {
        super.onResume();
        loadInventory();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_inventory, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_alert_settings) {
            showAlertSettingsDialog();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Loads all records from the repository and rebuilds the SKU index.
     */
    private void loadInventory() {
        inventoryRepository.getAllItems(result -> {
            allItems.clear();
            allItems.addAll(result);

            /*
             * Building the HashMap index takes O(n), but exact SKU lookups
             * afterward have average O(1) time complexity.
             */
            skuIndex = InventoryAlgorithms.buildSkuIndex(allItems);

            applyInventoryAlgorithms();
            updateStatistics();
        });
    }

    /**
     * Applies partial-text filtering, optional low-stock filtering, and custom
     * merge sorting to the inventory.
     */
    private void applyInventoryAlgorithms() {
        if (adapter == null || editSearchInventory == null) {
            return;
        }

        String query =
                editSearchInventory.getText() == null
                        ? ""
                        : editSearchInventory.getText().toString();

        boolean lowStockOnly =
                checkLowStockOnly != null
                        && checkLowStockOnly.isChecked();

        List<InventoryItem> filteredItems;

        /*
         * Check the HashMap first for an exact SKU match. This provides average
         * O(1) lookup time instead of scanning every inventory record.
         */
        InventoryItem exactSkuMatch = findItemByExactSku(query);

        if (!query.trim().isEmpty() && exactSkuMatch != null) {
            filteredItems = new ArrayList<>();

            if (!lowStockOnly || exactSkuMatch.isLowStock()) {
                filteredItems.add(exactSkuMatch);
            }
        } else {
            /*
             * When there is no exact SKU match, use the normal O(n) partial-search
             * and low-stock filtering algorithm.
             */
            filteredItems = InventoryAlgorithms.filter(
                    allItems,
                    query,
                    lowStockOnly
            );
        }

        /*
         * If a specific category is selected, keep only records whose category
         * foreign key matches the selected category ID.
         */
        if (selectedCategoryId != -1) {
            List<InventoryItem> categoryFilteredItems = new ArrayList<>();

            for (InventoryItem item : filteredItems) {
                if (item.getCategoryId() == selectedCategoryId) {
                    categoryFilteredItems.add(item);
                }
            }

            filteredItems = categoryFilteredItems;
        }

        List<InventoryItem> sortedItems =
                InventoryAlgorithms.mergeSort(
                        filteredItems,
                        currentSortMode
                );

        displayedItems.clear();
        displayedItems.addAll(sortedItems);
        adapter.notifyDataSetChanged();

        updateEmptyState();
        updateResultCount();
    }

    /**
     * Displays the number of visible records compared with the full inventory.
     */
    private void updateResultCount() {
        textResultCount.setText(
                getString(
                        R.string.inventory_result_count,
                        displayedItems.size(),
                        allItems.size()
                )
        );
    }

    /**
     * Displays or hides the empty-state message.
     */
    private void updateEmptyState() {
        textEmpty.setVisibility(
                displayedItems.isEmpty()
                        ? View.VISIBLE
                        : View.GONE
        );
    }

    /**
     * Calculates inventory statistics in one O(n) traversal.
     */
    private void updateStatistics() {
        InventoryAlgorithms.InventoryStatistics statistics =
                InventoryAlgorithms.calculateStatistics(allItems);

        InventoryItem lowestQuantityItem =
                statistics.getLowestQuantityItem();

        String lowestItemName =
                lowestQuantityItem == null
                        ? getString(R.string.no_lowest_quantity_item)
                        : lowestQuantityItem.getName();

        textStatistics.setText(
                getString(
                        R.string.inventory_statistics,
                        statistics.getDistinctItemCount(),
                        statistics.getTotalUnitCount(),
                        statistics.getLowStockCount(),
                        lowestItemName
                )
        );
    }

    /**
     * Demonstrates the HashMap SKU index. This method can be reused later for
     * an exact-SKU search button or barcode-scanning feature.
     */
    private InventoryItem findItemByExactSku(String sku) {
        if (skuIndex == null) {
            return null;
        }

        return InventoryAlgorithms.findByExactSku(skuIndex, sku);
    }

    // -------------------------------------------------------------------------
    // Adapter callbacks
    // -------------------------------------------------------------------------

    /**
     * Updates an item's quantity, refreshes the visible list, and checks for a
     * low-stock condition.
     */
    @Override
    public void onQuantityChanged(
            @NonNull InventoryItem item,
            int delta) {

        int newQuantity =
                Math.max(0, item.getQuantity() + delta);

        inventoryRepository.updateQuantity(
                item.getId(),
                newQuantity,
                success -> {
                    if (!success) {
                        Toast.makeText(
                                this,
                                R.string.error_save_failed,
                                Toast.LENGTH_SHORT
                        ).show();
                        return;
                    }

                    item.setQuantity(newQuantity);

                    /*
                     * Reapply algorithms because a quantity change may affect
                     * sorting, low-stock filtering, and statistics.
                     */
                    applyInventoryAlgorithms();
                    updateStatistics();

                    if (item.isLowStock()) {
                        maybeSendLowStockAlert(item);
                    }
                }
        );
    }

    /**
     * Deletes an inventory record and reloads the full dataset.
     */
    @Override
    public void onDeleteRequested(
            @NonNull InventoryItem item) {

        inventoryRepository.deleteItem(
                item.getId(),
                success -> {
                    if (success) {
                        loadInventory();

                        Toast.makeText(
                                this,
                                getString(
                                        R.string.item_removed,
                                        item.getName()
                                ),
                                Toast.LENGTH_SHORT
                        ).show();
                    } else {
                        Toast.makeText(
                                this,
                                R.string.error_save_failed,
                                Toast.LENGTH_SHORT
                        ).show();
                    }
                }
        );
    }

    // -------------------------------------------------------------------------
    // Alert settings
    // -------------------------------------------------------------------------

    /**
     * Displays the SMS alert destination settings dialog.
     */
    private void showAlertSettingsDialog() {
        View dialogView =
                LayoutInflater.from(this)
                        .inflate(
                                R.layout.dialog_alert_settings,
                                null
                        );

        TextInputEditText editPhoneNumber =
                dialogView.findViewById(
                        R.id.editAlertPhoneNumber
                );

        editPhoneNumber.setText(
                alertSettings.getPhoneNumber()
        );

        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.action_alert_settings)
                .setView(dialogView)
                .setPositiveButton(
                        R.string.button_save,
                        (dialog, which) -> {
                            String number =
                                    editPhoneNumber.getText() == null
                                            ? ""
                                            : editPhoneNumber
                                            .getText()
                                            .toString()
                                            .trim();

                            if (ValidationUtils.isBlank(number)) {
                                Toast.makeText(
                                        this,
                                        R.string.error_phone_required,
                                        Toast.LENGTH_SHORT
                                ).show();
                                return;
                            }

                            alertSettings.setPhoneNumber(number);

                            Toast.makeText(
                                    this,
                                    R.string.alert_settings_saved,
                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                )
                .setNegativeButton(
                        R.string.button_cancel,
                        null
                )
                .show();
    }

    // -------------------------------------------------------------------------
    // SMS handling
    // -------------------------------------------------------------------------

    /**
     * Requests SMS permission when necessary and sends a low-stock alert.
     */
    private void maybeSendLowStockAlert(
            InventoryItem item) {

        String message =
                getString(
                        R.string.sms_low_stock_alert,
                        item.getName(),
                        item.getQuantity()
                );

        boolean granted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        if (granted) {
            sendSms(message);
        } else {
            pendingAlertMessage = message;
            requestSmsPermission.launch(
                    Manifest.permission.SEND_SMS
            );
        }
    }

    /**
     * Sends the SMS alert while preventing failures from crashing the app.
     */
    private void sendSms(String message) {
        try {
            SmsManager smsManager;

            if (Build.VERSION.SDK_INT
                    >= Build.VERSION_CODES.S) {

                smsManager =
                        getSystemService(
                                SmsManager.class
                        );
            } else {
                smsManager =
                        SmsManager.getDefault();
            }

            smsManager.sendTextMessage(
                    alertSettings.getPhoneNumber(),
                    null,
                    message,
                    null,
                    null
            );

            Toast.makeText(
                    this,
                    R.string.sms_sent,
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception exception) {
            Toast.makeText(
                    this,
                    R.string.sms_failed,
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}