package com.mobile2app.inventory;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.List;

/**
 * Binds the list of {@link InventoryItem} records to the grid. Each cell shows
 * the item's name, SKU, and quantity, plus controls to increase or decrease the
 * quantity (UPDATE) and to remove the item (DELETE). Low-stock items are tinted
 * so they stand out.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ItemViewHolder> {

    /**
     * Lets the hosting activity react to row actions without the adapter needing
     * to know anything about the database or SMS logic.
     */
    public interface OnItemActionListener {
        void onQuantityChanged(@NonNull InventoryItem item, int delta);
        void onDeleteRequested(@NonNull InventoryItem item);
    }

    private final List<InventoryItem> items;
    private final OnItemActionListener listener;

    public InventoryAdapter(List<InventoryItem> items, OnItemActionListener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory_cell, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        InventoryItem item = items.get(position);

        holder.textName.setText(item.getName());

        String skuText = item.getSku() == null || item.getSku().trim().isEmpty()
                ? "SKU: None"
                : "SKU: " + item.getSku();

        holder.textSku.setText(skuText);

        String categoryName = item.getCategoryName() == null
                || item.getCategoryName().trim().isEmpty()
                ? "Uncategorized"
                : item.getCategoryName();

        holder.textCategory.setText(categoryName);
        holder.textQuantity.setText(String.valueOf(item.getQuantity()));

        // Highlight low-stock items in red so they're easy to spot in the grid.
        int color = item.isLowStock() ? Color.parseColor("#C62828") : Color.parseColor("#212121");
        holder.textQuantity.setTextColor(color);

        // UPDATE controls.
        holder.buttonIncrease.setOnClickListener(v -> listener.onQuantityChanged(item, +1));
        holder.buttonDecrease.setOnClickListener(v -> listener.onQuantityChanged(item, -1));

        // DELETE control.
        holder.buttonDelete.setOnClickListener(v -> listener.onDeleteRequested(item));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    /** Caches the views for one grid cell so they aren't looked up repeatedly. */
    static class ItemViewHolder extends RecyclerView.ViewHolder {
        final TextView textName;
        final TextView textSku;
        final TextView textCategory;
        final TextView textQuantity;
        final ImageButton buttonIncrease;
        final ImageButton buttonDecrease;
        final MaterialButton buttonDelete;

        ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            textName = itemView.findViewById(R.id.textItemName);
            textSku = itemView.findViewById(R.id.textItemSku);
            textCategory = itemView.findViewById(R.id.textItemCategory);
            textQuantity = itemView.findViewById(R.id.textItemQuantity);
            buttonIncrease = itemView.findViewById(R.id.buttonIncrease);
            buttonDecrease = itemView.findViewById(R.id.buttonDecrease);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
