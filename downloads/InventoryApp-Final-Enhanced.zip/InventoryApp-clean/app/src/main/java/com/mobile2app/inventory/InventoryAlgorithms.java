package com.mobile2app.inventory;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Contains reusable searching, filtering, indexing, sorting, and analytics
 * algorithms for inventory records.
 *
 * <p>Keeping these algorithms outside InventoryActivity separates the
 * presentation layer from the data-processing logic and makes the algorithms
 * easier to test and reuse.</p>
 */
public final class InventoryAlgorithms {

    /**
     * Available sorting strategies for the inventory list.
     */
    public enum SortMode {
        NAME_ASCENDING,
        QUANTITY_ASCENDING,
        QUANTITY_DESCENDING,
        LOW_STOCK_FIRST
    }

    private InventoryAlgorithms() {
        // Utility class; prevent construction.
    }

    /**
     * Creates a HashMap index using normalized SKU values as keys.
     *
     * Average construction complexity: O(n)
     * Average exact lookup complexity after construction: O(1)
     */
    @NonNull
    public static Map<String, InventoryItem> buildSkuIndex(
            @NonNull List<InventoryItem> items) {

        Map<String, InventoryItem> skuIndex = new HashMap<>();

        for (InventoryItem item : items) {
            String normalizedSku = normalize(item.getSku());

            if (!normalizedSku.isEmpty()) {
                skuIndex.put(normalizedSku, item);
            }
        }

        return skuIndex;
    }

    /**
     * Finds an inventory item by exact SKU using a previously constructed
     * HashMap index.
     *
     * Average lookup complexity: O(1)
     */
    public static InventoryItem findByExactSku(
            @NonNull Map<String, InventoryItem> skuIndex,
            String sku) {

        return skuIndex.get(normalize(sku));
    }

    /**
     * Filters inventory records by a partial name or SKU query and optionally
     * limits the result to low-stock records.
     *
     * Time complexity: O(n)
     * Additional space complexity: O(n)
     */
    @NonNull
    public static List<InventoryItem> filter(
            @NonNull List<InventoryItem> items,
            String query,
            boolean lowStockOnly) {

        String normalizedQuery = normalize(query);
        List<InventoryItem> filteredItems = new ArrayList<>();

        for (InventoryItem item : items) {
            boolean matchesQuery =
                    normalizedQuery.isEmpty()
                            || normalize(item.getName()).contains(normalizedQuery)
                            || normalize(item.getSku()).contains(normalizedQuery);

            boolean matchesStockFilter =
                    !lowStockOnly || item.isLowStock();

            if (matchesQuery && matchesStockFilter) {
                filteredItems.add(item);
            }
        }

        return filteredItems;
    }

    /**
     * Returns a newly sorted list without modifying the original list.
     *
     * This method uses a custom stable merge-sort implementation.
     *
     * Time complexity: O(n log n)
     * Additional space complexity: O(n)
     */
    @NonNull
    public static List<InventoryItem> mergeSort(
            @NonNull List<InventoryItem> items,
            @NonNull SortMode sortMode) {

        List<InventoryItem> copy = new ArrayList<>(items);

        if (copy.size() < 2) {
            return copy;
        }

        Comparator<InventoryItem> comparator = getComparator(sortMode);
        return mergeSortRecursive(copy, comparator);
    }

    /**
     * Calculates summary statistics in one pass through the list.
     *
     * Time complexity: O(n)
     */
    @NonNull
    public static InventoryStatistics calculateStatistics(
            @NonNull List<InventoryItem> items) {

        int totalUnits = 0;
        int lowStockCount = 0;
        InventoryItem lowestQuantityItem = null;

        for (InventoryItem item : items) {
            totalUnits += item.getQuantity();

            if (item.isLowStock()) {
                lowStockCount++;
            }

            if (lowestQuantityItem == null
                    || item.getQuantity() < lowestQuantityItem.getQuantity()) {
                lowestQuantityItem = item;
            }
        }

        return new InventoryStatistics(
                items.size(),
                totalUnits,
                lowStockCount,
                lowestQuantityItem
        );
    }

    @NonNull
    private static List<InventoryItem> mergeSortRecursive(
            @NonNull List<InventoryItem> items,
            @NonNull Comparator<InventoryItem> comparator) {

        if (items.size() <= 1) {
            return new ArrayList<>(items);
        }

        int middle = items.size() / 2;

        List<InventoryItem> left =
                mergeSortRecursive(
                        new ArrayList<>(items.subList(0, middle)),
                        comparator
                );

        List<InventoryItem> right =
                mergeSortRecursive(
                        new ArrayList<>(items.subList(middle, items.size())),
                        comparator
                );

        return merge(left, right, comparator);
    }

    @NonNull
    private static List<InventoryItem> merge(
            @NonNull List<InventoryItem> left,
            @NonNull List<InventoryItem> right,
            @NonNull Comparator<InventoryItem> comparator) {

        List<InventoryItem> merged =
                new ArrayList<>(left.size() + right.size());

        int leftIndex = 0;
        int rightIndex = 0;

        while (leftIndex < left.size() && rightIndex < right.size()) {
            InventoryItem leftItem = left.get(leftIndex);
            InventoryItem rightItem = right.get(rightIndex);

            /*
             * Choosing the left item when the values are equal preserves the
             * original ordering and makes the merge sort stable.
             */
            if (comparator.compare(leftItem, rightItem) <= 0) {
                merged.add(leftItem);
                leftIndex++;
            } else {
                merged.add(rightItem);
                rightIndex++;
            }
        }

        while (leftIndex < left.size()) {
            merged.add(left.get(leftIndex));
            leftIndex++;
        }

        while (rightIndex < right.size()) {
            merged.add(right.get(rightIndex));
            rightIndex++;
        }

        return merged;
    }

    @NonNull
    private static Comparator<InventoryItem> getComparator(
            @NonNull SortMode sortMode) {

        switch (sortMode) {
            case QUANTITY_ASCENDING:
                return Comparator
                        .comparingInt(InventoryItem::getQuantity)
                        .thenComparing(
                                InventoryItem::getName,
                                String.CASE_INSENSITIVE_ORDER
                        );

            case QUANTITY_DESCENDING:
                return Comparator
                        .comparingInt(InventoryItem::getQuantity)
                        .reversed()
                        .thenComparing(
                                InventoryItem::getName,
                                String.CASE_INSENSITIVE_ORDER
                        );

            case LOW_STOCK_FIRST:
                return Comparator
                        .comparing(InventoryItem::isLowStock)
                        .reversed()
                        .thenComparingInt(InventoryItem::getQuantity)
                        .thenComparing(
                                InventoryItem::getName,
                                String.CASE_INSENSITIVE_ORDER
                        );

            case NAME_ASCENDING:
            default:
                return Comparator.comparing(
                        InventoryItem::getName,
                        String.CASE_INSENSITIVE_ORDER
                );
        }
    }

    @NonNull
    private static String normalize(String value) {
        if (value == null) {
            return "";
        }

        return value.trim().toLowerCase(Locale.US);
    }

    /**
     * Immutable result object containing calculated inventory statistics.
     */
    public static final class InventoryStatistics {

        private final int distinctItemCount;
        private final int totalUnitCount;
        private final int lowStockCount;
        private final InventoryItem lowestQuantityItem;

        public InventoryStatistics(
                int distinctItemCount,
                int totalUnitCount,
                int lowStockCount,
                InventoryItem lowestQuantityItem) {

            this.distinctItemCount = distinctItemCount;
            this.totalUnitCount = totalUnitCount;
            this.lowStockCount = lowStockCount;
            this.lowestQuantityItem = lowestQuantityItem;
        }

        public int getDistinctItemCount() {
            return distinctItemCount;
        }

        public int getTotalUnitCount() {
            return totalUnitCount;
        }

        public int getLowStockCount() {
            return lowStockCount;
        }

        public InventoryItem getLowestQuantityItem() {
            return lowestQuantityItem;
        }
    }
}