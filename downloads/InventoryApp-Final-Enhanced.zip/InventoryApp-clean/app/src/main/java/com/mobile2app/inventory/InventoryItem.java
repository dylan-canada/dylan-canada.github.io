package com.mobile2app.inventory;

/**
 * Plain data holder for a single inventory record.
 *
 * <p>Each item mirrors one row of the {@code inventory} table: a database id,
 * a display name, an optional SKU, the current quantity on hand, and the
 * low-stock threshold that triggers an SMS alert when the quantity drops to or
 * below it.</p>
 */
public class InventoryItem {

    private final long id;
    private final String name;
    private final String sku;
    private int quantity;
    private final int lowStockThreshold;
    private long categoryId;
    private String categoryName;

    public InventoryItem(
            long id,
            String name,
            String sku,
            int quantity,
            int lowStockThreshold,
            long categoryId,
            String categoryName) {

        this.id = id;
        this.name = name;
        this.sku = sku;
        this.quantity = quantity;
        this.lowStockThreshold = lowStockThreshold;
        this.categoryId = categoryId;
        this.categoryName = categoryName;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getSku() {
        return sku;
    }

    public int getQuantity() {
        return quantity;
    }

    /** Quantity is mutable in memory so the grid reflects +/- taps immediately. */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getLowStockThreshold() {
        return lowStockThreshold;
    }

    /** True when stock has fallen to or below the configured threshold. */
    public boolean isLowStock() {
        return quantity <= lowStockThreshold;
    }

    public long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public InventoryItem(
            long id,
            String name,
            String sku,
            int quantity,
            int lowStockThreshold) {

        this(
                id,
                name,
                sku,
                quantity,
                lowStockThreshold,
                1L,
                "Uncategorized"
        );
    }
}
