package com.mobile2app.inventory;

import android.content.Context;

import java.util.List;

/**
 * Mediates inventory and category data access between the UI layer and
 * {@link DatabaseHelper}.
 *
 * <p>All SQLite operations run on a background thread through
 * {@link AppExecutors}, and all callbacks return to the main thread so the
 * Activities can safely update Android views.</p>
 */
public class InventoryRepository {

    /** Callback for operations that return inventory data. */
    public interface ItemsCallback {
        void onResult(List<InventoryItem> items);
    }

    /** Callback for operations that return category data. */
    public interface CategoriesCallback {
        void onResult(List<Category> categories);
    }

    /** Callback for CREATE, UPDATE, and DELETE operations. */
    public interface WriteCallback {
        void onResult(boolean success);
    }

    private final DatabaseHelper databaseHelper;
    private final AppExecutors executors;

    public InventoryRepository(Context context) {
        this.databaseHelper =
                new DatabaseHelper(context.getApplicationContext());
        this.executors = AppExecutors.getInstance();
    }

    // -------------------------------------------------------------------------
    // Inventory operations
    // -------------------------------------------------------------------------

    /**
     * READ: loads all inventory records and related category names in the
     * background.
     */
    public void getAllItems(ItemsCallback callback) {
        executors.diskIO(() -> {
            List<InventoryItem> items =
                    databaseHelper.getAllItems();

            executors.mainThread(
                    () -> callback.onResult(items)
            );
        });
    }

    /**
     * CREATE: inserts an item into the default Uncategorized category.
     *
     * <p>This overload preserves compatibility with existing code.</p>
     */
    public void addItem(
            String name,
            String sku,
            int quantity,
            int threshold,
            WriteCallback callback) {

        addItem(
                name,
                sku,
                quantity,
                threshold,
                1L,
                callback
        );
    }

    /**
     * CREATE: inserts an item with a selected category.
     */
    public void addItem(
            String name,
            String sku,
            int quantity,
            int threshold,
            long categoryId,
            WriteCallback callback) {

        executors.diskIO(() -> {
            long newId =
                    databaseHelper.addItem(
                            name,
                            sku,
                            quantity,
                            threshold,
                            categoryId
                    );

            executors.mainThread(
                    () -> callback.onResult(newId != -1)
            );
        });
    }

    /**
     * UPDATE: persists a new quantity for one item.
     */
    public void updateQuantity(
            long id,
            int newQuantity,
            WriteCallback callback) {

        executors.diskIO(() -> {
            int rowsAffected =
                    databaseHelper.updateQuantity(
                            id,
                            newQuantity
                    );

            executors.mainThread(
                    () -> callback.onResult(rowsAffected > 0)
            );
        });
    }

    /**
     * UPDATE: persists all editable inventory fields, including category.
     */
    public void updateItem(
            long itemId,
            String name,
            String sku,
            int quantity,
            int threshold,
            long categoryId,
            WriteCallback callback) {

        executors.diskIO(() -> {
            int rowsAffected =
                    databaseHelper.updateItem(
                            itemId,
                            name,
                            sku,
                            quantity,
                            threshold,
                            categoryId
                    );

            executors.mainThread(
                    () -> callback.onResult(rowsAffected > 0)
            );
        });
    }

    /**
     * DELETE: removes one inventory record.
     */
    public void deleteItem(
            long id,
            WriteCallback callback) {

        executors.diskIO(() -> {
            int rowsAffected =
                    databaseHelper.deleteItem(id);

            executors.mainThread(
                    () -> callback.onResult(rowsAffected > 0)
            );
        });
    }

    // -------------------------------------------------------------------------
    // Category operations
    // -------------------------------------------------------------------------

    /**
     * READ: loads all categories alphabetically.
     */
    public void getAllCategories(
            CategoriesCallback callback) {

        executors.diskIO(() -> {
            List<Category> categories =
                    databaseHelper.getAllCategories();

            executors.mainThread(
                    () -> callback.onResult(categories)
            );
        });
    }

    /**
     * CREATE: inserts a new category.
     */
    public void addCategory(
            String categoryName,
            WriteCallback callback) {

        executors.diskIO(() -> {
            long newId =
                    databaseHelper.addCategory(
                            categoryName
                    );

            executors.mainThread(
                    () -> callback.onResult(newId != -1)
            );
        });
    }

    /**
     * UPDATE: renames an existing category.
     */
    public void updateCategory(
            long categoryId,
            String categoryName,
            WriteCallback callback) {

        executors.diskIO(() -> {
            int rowsAffected =
                    databaseHelper.updateCategory(
                            categoryId,
                            categoryName
                    );

            executors.mainThread(
                    () -> callback.onResult(rowsAffected > 0)
            );
        });
    }

    /**
     * DELETE: removes an unused category.
     *
     * <p>The database foreign key prevents deletion when inventory items still
     * reference the category.</p>
     */
    public void deleteCategory(
            long categoryId,
            WriteCallback callback) {

        executors.diskIO(() -> {
            int rowsAffected =
                    databaseHelper.deleteCategory(
                            categoryId
                    );

            executors.mainThread(
                    () -> callback.onResult(rowsAffected > 0)
            );
        });
    }
}