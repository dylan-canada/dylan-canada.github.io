package com.mobile2app.inventory;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * First screen the user sees. Handles both signing in with an existing account
 * and creating a new one, checking everything against the SQLite database.
 *
 * <p>Behaviour required by the rubric:</p>
 * <ul>
 *     <li>Log In checks the username/password against the database.</li>
 *     <li>A first-time user can tap Create Account to add a new login that is
 *         saved to the users table.</li>
 * </ul>
 *
 * <p>Credential checks go through {@link AuthRepository} rather than calling
 * {@link DatabaseHelper} directly, so the SQLite work happens off the main
 * thread. Buttons are disabled while a request is in flight so a user can't
 * fire off a second login/create-account call before the first finishes.</p>
 */
public class LoginActivity extends AppCompatActivity {

    private AuthRepository authRepository;
    private TextInputEditText editUsername;
    private TextInputEditText editPassword;
    private MaterialButton buttonLogin;
    private MaterialButton buttonCreateAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        authRepository = new AuthRepository(this);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(v -> attemptLogin());
        buttonCreateAccount.setOnClickListener(v -> attemptCreateAccount());
    }

    /**
     * Validates the entered credentials against the database. On success the
     * inventory screen opens; otherwise the user is told the login failed.
     */
    private void attemptLogin() {
        String username = readField(editUsername);
        String password = readField(editPassword);

        if (!fieldsValid(username, password)) {
            return;
        }

        setFormEnabled(false);
        authRepository.login(username, password, success -> {
            setFormEnabled(true);
            if (success) {
                openInventory();
            } else {
                Toast.makeText(this, R.string.error_invalid_login, Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Creates a brand-new account, then proceeds to the inventory screen. If the
     * username is already taken the user is asked to log in instead.
     */
    private void attemptCreateAccount() {
        String username = readField(editUsername);
        String password = readField(editPassword);

        if (!fieldsValid(username, password)) {
            return;
        }

        setFormEnabled(false);
        authRepository.createAccount(username, password, created -> {
            setFormEnabled(true);
            if (created) {
                Toast.makeText(this, R.string.account_created, Toast.LENGTH_SHORT).show();
                openInventory();
            } else {
                Toast.makeText(this, R.string.error_username_taken, Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** Reads and trims the text from a field. */
    private String readField(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }

    /**
     * Guards against empty input and weak passwords, warning the user with a
     * specific message for each case.
     */
    private boolean fieldsValid(String username, String password) {
        if (ValidationUtils.isBlank(username) || ValidationUtils.isBlank(password)) {
            Toast.makeText(this, R.string.error_empty_fields, Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!ValidationUtils.isValidPassword(password)) {
            Toast.makeText(this, R.string.error_password_too_short, Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    /** Disables the buttons while a login/create-account call is in flight. */
    private void setFormEnabled(boolean enabled) {
        buttonLogin.setEnabled(enabled);
        buttonCreateAccount.setEnabled(enabled);
    }

    /** Moves to the inventory grid and finishes login so Back doesn't return here. */
    private void openInventory() {
        startActivity(new Intent(this, InventoryActivity.class));
        finish();
    }
}
