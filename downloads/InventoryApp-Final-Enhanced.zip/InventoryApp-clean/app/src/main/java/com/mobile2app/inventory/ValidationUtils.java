package com.mobile2app.inventory;

/**
 * Shared input-validation helpers for the login, account-creation, and
 * add-item forms.
 *
 * <p>Deliberately written in plain Java with no Android framework calls
 * (no {@code TextUtils}, no {@code Context}), so it can be covered by fast,
 * local JUnit tests that don't need an emulator or device.</p>
 */
public final class ValidationUtils {

    /** Minimum password length required for login and account creation. */
    public static final int MIN_PASSWORD_LENGTH = 6;

    private ValidationUtils() {
        // Utility class; not instantiable.
    }

    /** True when the value is null, empty, or only whitespace. */
    public static boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    /**
     * True when the password meets the app's minimum length requirement.
     * Called during both login and account creation.
     */
    public static boolean isValidPassword(String password) {
        return password != null && password.length() >= MIN_PASSWORD_LENGTH;
    }

    /**
     * Parses a quantity/threshold field into a non-negative integer.
     *
     * @return the parsed value, {@code 0} if the field was left blank, or
     *         {@code null} if the text is not a valid non-negative integer
     *         (lets the caller distinguish "left blank" from "entered
     *         garbage" and show an error only for the latter).
     */
    public static Integer parseNonNegativeInt(String value) {
        if (isBlank(value)) {
            return 0;
        }
        try {
            int parsed = Integer.parseInt(value.trim());
            return parsed < 0 ? null : parsed;
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
