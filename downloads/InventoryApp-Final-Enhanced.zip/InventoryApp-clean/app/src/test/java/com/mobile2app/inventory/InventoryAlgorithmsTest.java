package com.mobile2app.inventory;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class InventoryAlgorithmsTest {

    private InventoryItem keyboard;
    private InventoryItem mouse;
    private InventoryItem monitor;
    private List<InventoryItem> items;

    @Before
    public void setUp() {
        keyboard = new InventoryItem(
                1,
                "Keyboard",
                "KEY-100",
                8,
                3
        );

        mouse = new InventoryItem(
                2,
                "Wireless Mouse",
                "MOU-200",
                2,
                3
        );

        monitor = new InventoryItem(
                3,
                "Monitor",
                "MON-300",
                12,
                4
        );

        items = new ArrayList<>(
                Arrays.asList(keyboard, mouse, monitor)
        );
    }

    @Test
    public void buildSkuIndexSupportsExactLookup() {
        Map<String, InventoryItem> index =
                InventoryAlgorithms.buildSkuIndex(items);

        InventoryItem result =
                InventoryAlgorithms.findByExactSku(index, "mou-200");

        assertSame(mouse, result);
    }

    @Test
    public void exactSkuLookupReturnsNullForUnknownSku() {
        Map<String, InventoryItem> index =
                InventoryAlgorithms.buildSkuIndex(items);

        InventoryItem result =
                InventoryAlgorithms.findByExactSku(index, "UNKNOWN");

        assertNull(result);
    }

    @Test
    public void filterMatchesPartialItemName() {
        List<InventoryItem> result =
                InventoryAlgorithms.filter(items, "wireless", false);

        assertEquals(1, result.size());
        assertSame(mouse, result.get(0));
    }

    @Test
    public void filterMatchesPartialSku() {
        List<InventoryItem> result =
                InventoryAlgorithms.filter(items, "mon", false);

        assertEquals(1, result.size());
        assertSame(monitor, result.get(0));
    }

    @Test
    public void filterReturnsOnlyLowStockItems() {
        List<InventoryItem> result =
                InventoryAlgorithms.filter(items, "", true);

        assertEquals(1, result.size());
        assertSame(mouse, result.get(0));
    }

    @Test
    public void mergeSortOrdersNamesAlphabetically() {
        List<InventoryItem> result =
                InventoryAlgorithms.mergeSort(
                        items,
                        InventoryAlgorithms.SortMode.NAME_ASCENDING
                );

        assertEquals("Keyboard", result.get(0).getName());
        assertEquals("Monitor", result.get(1).getName());
        assertEquals("Wireless Mouse", result.get(2).getName());
    }

    @Test
    public void mergeSortOrdersQuantityAscending() {
        List<InventoryItem> result =
                InventoryAlgorithms.mergeSort(
                        items,
                        InventoryAlgorithms.SortMode.QUANTITY_ASCENDING
                );

        assertSame(mouse, result.get(0));
        assertSame(keyboard, result.get(1));
        assertSame(monitor, result.get(2));
    }

    @Test
    public void mergeSortOrdersQuantityDescending() {
        List<InventoryItem> result =
                InventoryAlgorithms.mergeSort(
                        items,
                        InventoryAlgorithms.SortMode.QUANTITY_DESCENDING
                );

        assertSame(monitor, result.get(0));
        assertSame(keyboard, result.get(1));
        assertSame(mouse, result.get(2));
    }

    @Test
    public void lowStockSortPlacesLowStockItemsFirst() {
        List<InventoryItem> result =
                InventoryAlgorithms.mergeSort(
                        items,
                        InventoryAlgorithms.SortMode.LOW_STOCK_FIRST
                );

        assertSame(mouse, result.get(0));
    }

    @Test
    public void calculateStatisticsReturnsExpectedValues() {
        InventoryAlgorithms.InventoryStatistics statistics =
                InventoryAlgorithms.calculateStatistics(items);

        assertEquals(3, statistics.getDistinctItemCount());
        assertEquals(22, statistics.getTotalUnitCount());
        assertEquals(1, statistics.getLowStockCount());
        assertSame(mouse, statistics.getLowestQuantityItem());
    }
}