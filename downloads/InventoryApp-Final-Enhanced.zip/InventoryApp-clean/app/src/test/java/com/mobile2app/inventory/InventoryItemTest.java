package com.mobile2app.inventory;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Local (JVM) unit tests for {@link InventoryItem}, in particular the
 * low-stock threshold logic that decides when an SMS alert fires.
 */
public class InventoryItemTest {

    @Test
    public void isLowStock_quantityAboveThreshold_returnsFalse() {
        InventoryItem item = new InventoryItem(1, "Widget", "SKU-1", 10, 5);
        assertFalse(item.isLowStock());
    }

    @Test
    public void isLowStock_quantityEqualToThreshold_returnsTrue() {
        InventoryItem item = new InventoryItem(1, "Widget", "SKU-1", 5, 5);
        assertTrue(item.isLowStock());
    }

    @Test
    public void isLowStock_quantityBelowThreshold_returnsTrue() {
        InventoryItem item = new InventoryItem(1, "Widget", "SKU-1", 2, 5);
        assertTrue(item.isLowStock());
    }

    @Test
    public void setQuantity_updatesLowStockResult() {
        InventoryItem item = new InventoryItem(1, "Widget", "SKU-1", 10, 5);
        assertFalse(item.isLowStock());

        item.setQuantity(3);
        assertTrue(item.isLowStock());
    }
}
