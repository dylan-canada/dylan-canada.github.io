package com.mobile2app.inventory;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Local (JVM) unit tests for {@link ValidationUtils}. These run on the local
 * JVM with no emulator or device needed, since ValidationUtils has no
 * Android framework dependencies.
 */
public class ValidationUtilsTest {

    @Test
    public void isBlank_nullAndEmptyAndWhitespace_returnsTrue() {
        assertTrue(ValidationUtils.isBlank(null));
        assertTrue(ValidationUtils.isBlank(""));
        assertTrue(ValidationUtils.isBlank("   "));
    }

    @Test
    public void isBlank_nonEmptyText_returnsFalse() {
        assertFalse(ValidationUtils.isBlank("widget"));
    }

    @Test
    public void isValidPassword_shortPassword_returnsFalse() {
        assertFalse(ValidationUtils.isValidPassword("abc"));
    }

    @Test
    public void isValidPassword_nullPassword_returnsFalse() {
        assertFalse(ValidationUtils.isValidPassword(null));
    }

    @Test
    public void isValidPassword_meetsMinimumLength_returnsTrue() {
        assertTrue(ValidationUtils.isValidPassword("abcdef"));
    }

    @Test
    public void parseNonNegativeInt_blankValue_returnsZero() {
        assertEquals(Integer.valueOf(0), ValidationUtils.parseNonNegativeInt(""));
        assertEquals(Integer.valueOf(0), ValidationUtils.parseNonNegativeInt(null));
    }

    @Test
    public void parseNonNegativeInt_validNumber_returnsParsedValue() {
        assertEquals(Integer.valueOf(42), ValidationUtils.parseNonNegativeInt("42"));
    }

    @Test
    public void parseNonNegativeInt_negativeNumber_returnsNull() {
        assertNull(ValidationUtils.parseNonNegativeInt("-5"));
    }

    @Test
    public void parseNonNegativeInt_nonNumericText_returnsNull() {
        assertNull(ValidationUtils.parseNonNegativeInt("abc"));
    }
}
