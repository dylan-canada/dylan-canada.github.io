package com.mobile2app.inventory;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * Form for adding a new inventory record (the CREATE operation). Collects the
 * item name, SKU, starting quantity, and low-stock threshold, writes the record
 * to the database, then returns to the grid.
 */
public class AddItemActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TextInputEditText editName;
    private TextInputEditText editSku;
    private TextInputEditText editQuantity;
    private TextInputEditText editThreshold;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        databaseHelper = new DatabaseHelper(this);

        editName = findViewById(R.id.editItemName);
        editSku = findViewById(R.id.editItemSku);
        editQuantity = findViewById(R.id.editItemQuantity);
        editThreshold = findViewById(R.id.editItemThreshold);

        MaterialButton buttonSave = findViewById(R.id.buttonSaveItem);
        MaterialButton buttonCancel = findViewById(R.id.buttonCancel);

        buttonSave.setOnClickListener(v -> saveItem());
        buttonCancel.setOnClickListener(v -> finish());
    }

    /**
     * Validates the form and inserts the new record. A blank name is rejected;
     * blank number fields default to 0 so the user isn't forced to fill them.
     */
    private void saveItem() {
        String name = readField(editName);
        String sku = readField(editSku);

        if (TextUtils.isEmpty(name)) {
            Toast.makeText(this, R.string.error_name_required, Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity = parseIntOrZero(readField(editQuantity));
        int threshold = parseIntOrZero(readField(editThreshold));

        long newId = databaseHelper.addItem(name, sku, quantity, threshold);
        if (newId != -1) {
            Toast.makeText(this, R.string.item_added, Toast.LENGTH_SHORT).show();
            finish(); // Return to the grid, which reloads in onResume.
        } else {
            Toast.makeText(this, R.string.error_save_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private String readField(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }

    /** Safely converts text to an int, defaulting to 0 for blank or bad input. */
    private int parseIntOrZero(String value) {
        if (TextUtils.isEmpty(value)) {
            return 0;
        }
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
