package com.mobile2app.inventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

/**
 * Central access point for the app's SQLite database.
 *
 * <p>The database is persistent: it lives on the device's internal storage and
 * keeps its contents between launches. It holds two tables:</p>
 * <ul>
 *     <li>{@code users}     – login credentials (username + hashed password)</li>
 *     <li>{@code inventory} – the stock records shown in the grid</li>
 * </ul>
 *
 * <p>This class only builds the database "shell" (the tables and the operations
 * that act on them). The user populates the inventory table at runtime through
 * the app.</p>
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database file name and schema version. Bump the version to trigger onUpgrade.
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    // ---- users table ----
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD_HASH = "password_hash";

    // ---- inventory table ----
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COL_ITEM_ID = "_id";
    private static final String COL_ITEM_NAME = "name";
    private static final String COL_ITEM_SKU = "sku";
    private static final String COL_ITEM_QUANTITY = "quantity";
    private static final String COL_ITEM_THRESHOLD = "low_stock_threshold";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Called the first time the database is created. Builds both tables.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                COL_PASSWORD_HASH + " TEXT NOT NULL)";
        db.execSQL(createUsers);

        String createInventory = "CREATE TABLE " + TABLE_INVENTORY + " (" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT NOT NULL, " +
                COL_ITEM_SKU + " TEXT, " +
                COL_ITEM_QUANTITY + " INTEGER NOT NULL DEFAULT 0, " +
                COL_ITEM_THRESHOLD + " INTEGER NOT NULL DEFAULT 0)";
        db.execSQL(createInventory);
    }

    /**
     * Called when DATABASE_VERSION increases. For this project we simply drop
     * and recreate; a production app would migrate existing data instead.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // ====================================================================
    //  User / authentication operations
    // ====================================================================

    /**
     * Returns true if the username already exists in the users table.
     */
    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + " = ?",
                new String[]{username},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    /**
     * Creates a new account. Returns true on success, or false if the username
     * is already taken (usernames must be unique).
     */
    public boolean createUser(String username, String password) {
        if (userExists(username)) {
            return false;
        }
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD_HASH, hash(password));
        long newRowId = db.insert(TABLE_USERS, null, values);
        return newRowId != -1;
    }

    /**
     * Checks a username/password pair against the stored credentials.
     *
     * @return true when the username exists and the password matches.
     */
    public boolean checkCredentials(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COL_PASSWORD_HASH},
                COL_USERNAME + " = ?",
                new String[]{username},
                null, null, null);

        boolean valid = false;
        if (cursor.moveToFirst()) {
            String storedHash = cursor.getString(0);
            valid = storedHash.equals(hash(password));
        }
        cursor.close();
        return valid;
    }

    /**
     * Hashes a plain-text password with SHA-256 so the raw password is never
     * written to the database. This is a teaching-level safeguard; a production
     * app would add a per-user salt.
     */
    private String hash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(input.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            // SHA-256 is guaranteed to be available on Android, so this never fires.
            throw new RuntimeException("SHA-256 not available", e);
        }
    }

    // ====================================================================
    //  Inventory CRUD operations
    // ====================================================================

    /**
     * CREATE: inserts a new inventory record and returns its generated id.
     */
    public long addItem(String name, String sku, int quantity, int threshold) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_SKU, sku);
        values.put(COL_ITEM_QUANTITY, quantity);
        values.put(COL_ITEM_THRESHOLD, threshold);
        return db.insert(TABLE_INVENTORY, null, values);
    }

    /**
     * READ: returns every inventory record, ordered by name, for the grid.
     */
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_INVENTORY,
                null, null, null, null, null,
                COL_ITEM_NAME + " ASC");

        while (cursor.moveToNext()) {
            InventoryItem item = new InventoryItem(
                    cursor.getLong(cursor.getColumnIndexOrThrow(COL_ITEM_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_SKU)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_QUANTITY)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_THRESHOLD)));
            items.add(item);
        }
        cursor.close();
        return items;
    }

    /**
     * UPDATE: changes the quantity of one record. Used by the +/- controls on
     * each grid row. Returns the number of rows affected (1 on success).
     */
    public int updateQuantity(long id, int newQuantity) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_QUANTITY, newQuantity);
        return db.update(
                TABLE_INVENTORY,
                values,
                COL_ITEM_ID + " = ?",
                new String[]{String.valueOf(id)});
    }

    /**
     * DELETE: removes one record by id. Returns the number of rows deleted.
     */
    public int deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(
                TABLE_INVENTORY,
                COL_ITEM_ID + " = ?",
                new String[]{String.valueOf(id)});
    }
}
