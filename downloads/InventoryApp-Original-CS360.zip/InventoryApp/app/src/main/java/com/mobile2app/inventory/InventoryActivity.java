package com.mobile2app.inventory;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.ArrayList;
import java.util.List;

/**
 * Main screen after sign-in. Shows every inventory record in a grid and lets the
 * user create, read, update, and delete records. When a quantity drops to or
 * below its low-stock threshold, the app offers to send an SMS alert (subject to
 * the user granting the SEND_SMS permission).
 */
public class InventoryActivity extends AppCompatActivity
        implements InventoryAdapter.OnItemActionListener {

    // A fixed demo destination for low-stock alerts. A production build would
    // let the user set this in a settings screen.
    private static final String ALERT_PHONE_NUMBER = "5551234567";

    private DatabaseHelper databaseHelper;
    private InventoryAdapter adapter;
    private TextView textEmpty;

    private final List<InventoryItem> items = new ArrayList<>();

    // Remembers the alert text to send once the permission result comes back,
    // so a fresh grant can still deliver the message that triggered the request.
    private String pendingAlertMessage;

    /**
     * Runtime permission launcher for SEND_SMS. The result callback decides what
     * happens based on whether the user grants or denies the request.
     */
    private final ActivityResultLauncher<String> requestSmsPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        if (isGranted) {
                            // Permission just granted: deliver the queued alert.
                            if (pendingAlertMessage != null) {
                                sendSms(pendingAlertMessage);
                            }
                        } else {
                            // Denied: the app keeps working, just without alerts.
                            Toast.makeText(this,
                                    R.string.sms_denied_keep_working,
                                    Toast.LENGTH_LONG).show();
                        }
                        pendingAlertMessage = null;
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        databaseHelper = new DatabaseHelper(this);
        textEmpty = findViewById(R.id.textEmpty);

        // Two-column grid display of the inventory records.
        RecyclerView recyclerView = findViewById(R.id.recyclerInventory);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        adapter = new InventoryAdapter(items, this);
        recyclerView.setAdapter(adapter);

        ExtendedFloatingActionButton fabAdd = findViewById(R.id.fabAddItem);
        fabAdd.setOnClickListener(v ->
                startActivity(new Intent(this, AddItemActivity.class)));
    }

    /** Reload from the database every time the screen returns to the foreground. */
    @Override
    protected void onResume() {
        super.onResume();
        loadInventory();
    }

    /** READ: pull all records from the database into the grid. */
    private void loadInventory() {
        items.clear();
        items.addAll(databaseHelper.getAllItems());
        adapter.notifyDataSetChanged();
        textEmpty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    // ----- Adapter callbacks (UPDATE and DELETE) -----

    /**
     * UPDATE: the user tapped + or - on a row. Persist the new quantity, then
     * check whether the change pushed the item into low-stock territory.
     */
    @Override
    public void onQuantityChanged(@NonNull InventoryItem item, int delta) {
        int newQuantity = Math.max(0, item.getQuantity() + delta);
        databaseHelper.updateQuantity(item.getId(), newQuantity);
        item.setQuantity(newQuantity);
        adapter.notifyDataSetChanged();

        if (item.isLowStock()) {
            maybeSendLowStockAlert(item);
        }
    }

    /**
     * DELETE: the user tapped the remove button on a row. Remove it from the
     * database and refresh the grid.
     */
    @Override
    public void onDeleteRequested(@NonNull InventoryItem item) {
        databaseHelper.deleteItem(item.getId());
        loadInventory();
        Toast.makeText(this,
                getString(R.string.item_removed, item.getName()),
                Toast.LENGTH_SHORT).show();
    }

    // ----- SMS handling -----

    /**
     * Builds a low-stock alert and either sends it immediately (permission
     * already granted) or requests the permission first. Either way the rest of
     * the app stays fully functional.
     */
    private void maybeSendLowStockAlert(InventoryItem item) {
        String message = getString(R.string.sms_low_stock_alert,
                item.getName(), item.getQuantity());

        boolean granted = ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        if (granted) {
            sendSms(message);
        } else {
            // Queue the message and ask for permission. The launcher callback
            // sends it if the user agrees.
            pendingAlertMessage = message;
            requestSmsPermission.launch(Manifest.permission.SEND_SMS);
        }
    }

    /**
     * Actually dispatches the SMS. Only ever called once permission is granted.
     * Wrapped in try/catch so a send failure can't crash the app.
     */
    private void sendSms(String message) {
        try {
            // SmsManager is obtained differently before and after Android 12 (API 31).
            SmsManager smsManager;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                smsManager = getSystemService(SmsManager.class);
            } else {
                smsManager = SmsManager.getDefault();
            }
            smsManager.sendTextMessage(ALERT_PHONE_NUMBER, null, message, null, null);
            Toast.makeText(this, R.string.sms_sent, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, R.string.sms_failed, Toast.LENGTH_SHORT).show();
        }
    }
}
