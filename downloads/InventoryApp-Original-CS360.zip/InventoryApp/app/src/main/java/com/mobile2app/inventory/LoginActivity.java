package com.mobile2app.inventory;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

/**
 * First screen the user sees. Handles both signing in with an existing account
 * and creating a new one, checking everything against the SQLite database.
 *
 * <p>Behaviour required by the rubric:</p>
 * <ul>
 *     <li>Log In checks the username/password against the database.</li>
 *     <li>A first-time user can tap Create Account to add a new login that is
 *         saved to the users table.</li>
 * </ul>
 */
public class LoginActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;
    private TextInputEditText editUsername;
    private TextInputEditText editPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new DatabaseHelper(this);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        MaterialButton buttonLogin = findViewById(R.id.buttonLogin);
        MaterialButton buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogin.setOnClickListener(v -> attemptLogin());
        buttonCreateAccount.setOnClickListener(v -> attemptCreateAccount());
    }

    /**
     * Validates the entered credentials against the database. On success the
     * inventory screen opens; otherwise the user is told the login failed.
     */
    private void attemptLogin() {
        String username = readField(editUsername);
        String password = readField(editPassword);

        if (!fieldsFilled(username, password)) {
            return;
        }

        if (databaseHelper.checkCredentials(username, password)) {
            openInventory();
        } else {
            Toast.makeText(this,
                    R.string.error_invalid_login,
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Creates a brand-new account, then proceeds to the inventory screen. If the
     * username is already taken the user is asked to log in instead.
     */
    private void attemptCreateAccount() {
        String username = readField(editUsername);
        String password = readField(editPassword);

        if (!fieldsFilled(username, password)) {
            return;
        }

        if (databaseHelper.createUser(username, password)) {
            Toast.makeText(this,
                    R.string.account_created,
                    Toast.LENGTH_SHORT).show();
            openInventory();
        } else {
            Toast.makeText(this,
                    R.string.error_username_taken,
                    Toast.LENGTH_SHORT).show();
        }
    }

    /** Reads and trims the text from a field. */
    private String readField(TextInputEditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }

    /** Guards against empty input and warns the user if either field is blank. */
    private boolean fieldsFilled(String username, String password) {
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this,
                    R.string.error_empty_fields,
                    Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    /** Moves to the inventory grid and finishes login so Back doesn't return here. */
    private void openInventory() {
        startActivity(new Intent(this, InventoryActivity.class));
        finish();
    }
}
